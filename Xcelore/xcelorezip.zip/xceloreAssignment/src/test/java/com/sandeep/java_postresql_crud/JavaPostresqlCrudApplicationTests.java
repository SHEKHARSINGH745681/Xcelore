package com.sandeep.java_postresql_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaPostresqlCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
