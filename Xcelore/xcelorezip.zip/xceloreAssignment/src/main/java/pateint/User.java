package pateint;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "Pateint")
public class User {

	@Id
	@SequenceGenerator(name = "user_sequence", sequenceName = "user_sequence", allocationSize = 2)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_sequence")
	private Long id;
	@NotEmpty
	@Size(min=3,message = "Name must be min of 4 characters")
	private String pname;
	
	@Email(message = "email is not valid !!")
	private String email;
	@NotNull
	private String city;
	private String symptoms;
	
	//@NotEmpty
	//@Size(min=0,max=10,message = "number must be min of 10 digit")
	private String Phone_num;
	
	@Transient
	private Integer age;

	public User() {
	}

	public User(Long id, String pname, String email, String city, String symptoms, String Phone_num) {
		this.id = id;
		this.pname = pname;
		this.email = email;
		this.city = city;
		this.symptoms = symptoms;
		this.Phone_num = Phone_num;
	}

	public User(String pname, String email, String city) {
		this.pname = pname;
		this.email = email;
		this.city = city;
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return pname;
	}

	public void setName(String pname) {
		this.pname = pname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getsymptoms() {
		return symptoms;
	}

	public void setSpeciality(String symptoms) {
		this.symptoms = symptoms;
	}

	public String getPhone_num() {
		return Phone_num;
	}

	public void setPhone_num(String phone_num) {
		Phone_num = phone_num;
	}

	
	

}