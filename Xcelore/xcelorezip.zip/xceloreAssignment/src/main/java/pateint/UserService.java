package pateint;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.shekhar.java_xcelore.user.User;
import com.shekhar.java_xcelore.user.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserService {
	private final UserRepository userRepository;

	@Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

	public List<User> getStudents() {
		return userRepository.findAll();
	}

	public void addNewStudent(User user) {
		Optional<User> userOptional = userRepository.findStudentByEmail(user.getEmail());
		if (userOptional.isPresent()) {
			throw new IllegalStateException("email exist");
		}
		userRepository.save(user);
	}

	public void deleteStudent(Long userId) {
		boolean exist = userRepository.existsById(userId);
		if (!exist) {
			throw new IllegalStateException("User with ID " + userId + " does not exist");
		}
		userRepository.deleteById(userId);
	}

	@Transactional
	public void updateStudent(Long userId, String name, String email) {
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new IllegalStateException("Student with ID " + userId + " does not exist"));

		if (name != null && name.length() > 0 && !Objects.equals(name, user.getName())) {
			user.setName(name);
		}

		if (email != null && email.length() > 0 && !Objects.equals(email, user.getEmail())) {
			Optional<User> userOptional = userRepository.findStudentByEmail(email);
			if (userOptional.isPresent()) {
				throw new IllegalStateException("email exist");
			}
			user.setEmail(email);
		}

		userRepository.save(user);

	}


	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String,String>>handleMethodArgsNotValidException(MethodArgumentNotValidException ex){
		Map<String,String> resp=new HashMap<>() ;
		
		ex.getBindingResult().getAllErrors().forEach((error)->{
			String fieldName = ((FieldError)error).getField();
			String message = error.getDefaultMessage();
			resp.put(fieldName, message);
			
		});
		
		return new ResponseEntity<Map<String,String>>(resp,HttpStatus.BAD_REQUEST);
	}

}