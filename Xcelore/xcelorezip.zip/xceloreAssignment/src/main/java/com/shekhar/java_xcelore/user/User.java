package com.shekhar.java_xcelore.user;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.time.Period;

@Entity
@Table(name = "Doctor")
public class User {

	@Id
	@SequenceGenerator(name = "user_sequence", sequenceName = "user_sequence", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_sequence")
	private Long id;
	@NotEmpty
	@Size(min=3,message = "Name must be min of 4 characters")
	private String name;
	
	@Email(message = "email is not valid !!")
	private String email;
	@NotNull
	private String city;
	private String speciality;
	
	//@NotEmpty
	//@Size(min=0,max=10,message = "number must be min of 10 digit")
	private String Phone_num;
	
	@Transient
	private Integer age;

	public User() {
	}

	public User(Long id, String name, String email, String city, String speciality, String Phone_num) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.city = city;
		this.speciality = speciality;
		this.Phone_num = Phone_num;
	}

	public User(String name, String email, String city) {
		this.name = name;
		this.email = email;
		this.city = city;
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public String getPhone_num() {
		return Phone_num;
	}

	public void setPhone_num(String phone_num) {
		Phone_num = phone_num;
	}

	
	

}
