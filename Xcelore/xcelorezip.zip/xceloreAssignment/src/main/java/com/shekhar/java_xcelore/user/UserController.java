package com.shekhar.java_xcelore.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping(path = "add")
public class UserController {
	
	private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/all")
    public List<User> getStudent() {
        return userService.getStudents();
    }

    @PostMapping
    public String registerUser(@Valid @RequestBody User user) {
        userService.addNewStudent(user);
        return"created sucessfully";
    }

    @DeleteMapping(path = "{userId}")
    public String deleteUser(@PathVariable("userId") Long userId) {
        userService.deleteStudent(userId);
        return"deleted sucessfully";
    }

    @PutMapping(path = "{userId}")
    public void updateUser(@PathVariable("userId") Long userId,
                              @RequestParam(required = false) String name,
                              @RequestParam(required = false) String email){
        userService.updateStudent(userId, name, email);
    }	

}
